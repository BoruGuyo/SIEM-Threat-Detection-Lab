#!/usr/bin/env python3
"""Starter script for the Advanced SIEM lab."""

import json
import re
import sys
from pathlib import Path


LOCAL_FEED = Path("threat_feed.json")
WAZUH_FEED = Path("/var/ossec/ruleset/threat_feed.json")
ALERTS_FILE = Path("alerts.json")


def load_threat_feed():
    """
    Load the threat feed JSON.
    For CodeGrade, the file is expected in the working directory.
    In the live lab environment, Wazuh may use /var/ossec/ruleset/.
    """
    if LOCAL_FEED.exists():
        feed_path = LOCAL_FEED
    else:
        feed_path = WAZUH_FEED

    try:
        with feed_path.open("r", encoding="utf-8") as file:
            data = json.load(file)
    except FileNotFoundError:
        print("[ERROR] threat_feed.json not found.")
        sys.exit(1)
    except json.JSONDecodeError:
        print("[ERROR] threat_feed.json is not valid JSON.")
        sys.exit(1)

    data.setdefault("malicious_ips", [])
    data.setdefault("malicious_urls", [])
    data.setdefault("malicious_ports", [])
    return data


def extract_first_match(pattern, text):
    """Return the first regex capture group match, or None."""
    match = re.search(pattern, text)
    return match.group(1) if match else None


def extract_ip_fields(log_entry):
    """
    Extract source and destination IPs from the log entry.
    Returns:
        tuple: (src_ip, dst_ip)
    """
    src_ip = extract_first_match(
        r"\bsrc=([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)",
        log_entry,
    )
    dst_ip = extract_first_match(
        r"\bdst=([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)",
        log_entry,
    )
    return src_ip, dst_ip


def extract_url(log_entry):
    """
    Extract the first URL from the log entry, if present.
    Returns:
        str | None: The matched URL or None.
    """
    return extract_first_match(r'(https?://[^\s"\']+)', log_entry)


def extract_port_fields(log_entry):
    """
    Extract source and destination port values from the log entry.
    Returns:
        tuple: (spt_raw, dpt_raw)
    Note:
        These values are returned as strings. Students must safely
        convert them to integers before comparing against malicious ports.
    """
    spt_raw = extract_first_match(r"\bspt=(\S+)", log_entry)
    dpt_raw = extract_first_match(r"\bdpt=(\S+)", log_entry)
    return spt_raw, dpt_raw


def alert_ip_if_malicious(log_entry, threat_feed):
    """
    Detect malicious IP indicators in src/dst fields.
    TODO:
    1. Use extract_ip_fields(log_entry) to get src and dst IPs.
    2. Compare extracted IPs against threat_feed["malicious_ips"].
    3. Print an alert if a malicious IP is detected.
    4. Return True if a malicious IP is found; otherwise return False.
    """
    src_ip, dst_ip = extract_ip_fields(log_entry)
    malicious_ips = threat_feed.get("malicious_ips", [])
    threat_detected = False

    if src_ip and src_ip in malicious_ips:
        print(f"[ALERT] Malicious IP detected: src={src_ip}")
        threat_detected = True

    if dst_ip and dst_ip in malicious_ips:
        print(f"[ALERT] Malicious IP detected: dst={dst_ip}")
        threat_detected = True

    return threat_detected


def alert_url_if_malicious(log_entry, threat_feed):
    """
    Detect malicious URL indicators in the log entry.
    TODO:
    1. Extract the URL from the log entry.
    2. Compare the URL against threat_feed["malicious_urls"].
    3. Print an alert if a malicious URL is detected.
    4. Return True if a malicious URL is found; otherwise return False.
    """
    url = extract_url(log_entry)
    malicious_urls = threat_feed.get("malicious_urls", [])

    if url and url in malicious_urls:
        print(f"[ALERT] Malicious URL detected: {url}")
        return True

    return False


def alert_port_if_malicious(log_entry, threat_feed):
    """
    Detect malicious port indicators in spt/dpt fields.
    TODO:
    1. Use extract_port_fields(log_entry) to get raw source and destination
       port values.
    2. Safely convert port values to integers.
    3. Compare the ports against threat_feed["malicious_ports"].
    4. Print an alert if a malicious port is detected.
    5. Return True if a malicious port is found; otherwise return False.
    Hint:
        Invalid port values should be handled safely so the script does not
        crash with an unhandled exception.
    """
    spt_match = re.search(r"\bspt=(\S+)", log_entry)
    dpt_match = re.search(r"\bdpt=(\S+)", log_entry)
    malicious_ports = threat_feed.get("malicious_ports", [])
    threat_detected = False

    try:
        spt = int(spt_match.group(1)) if spt_match else None
        dpt = int(dpt_match.group(1)) if dpt_match else None
    except ValueError:
        print("[ERROR] Invalid port number detected.")
        sys.exit(1)

    spt_hit = spt is not None and spt in malicious_ports
    dpt_hit = dpt is not None and dpt in malicious_ports

    if spt_hit or dpt_hit:
        print(f"[ALERT] Malicious Port Detected: spt={spt} dpt={dpt}")
        threat_detected = True

    return threat_detected


def record_alert(log_entry):
    """
    Append a detected threat to alerts.json.

    TODO:
    Write a meaningful alert record that includes useful threat details
    from the log entry.
    """
    alert_record = {
        "log_entry": log_entry,
        "src_ip": extract_ip_fields(log_entry)[0],
        "dst_ip": extract_ip_fields(log_entry)[1],
        "url": extract_url(log_entry),
    }

    with open(ALERTS_FILE, "a", encoding="utf-8") as file:
        json.dump(alert_record, file)
        file.write("\n")


def main():
    """Process a single log entry and report detected threats."""
    if len(sys.argv) < 2:
        print("[ERROR] No log entry provided.")
        sys.exit(1)

    log_entry = sys.argv[1]
    threat_feed = load_threat_feed()
    threat_detected = False

    if alert_ip_if_malicious(log_entry, threat_feed):
        threat_detected = True

    if alert_url_if_malicious(log_entry, threat_feed):
        threat_detected = True

    if alert_port_if_malicious(log_entry, threat_feed):
        threat_detected = True

    if threat_detected:
        record_alert(log_entry)
        print("[ALERT] Threat recorded in alerts.json.")
    else:
        print("[INFO] No threats detected.")


if __name__ == "__main__":
    main()
